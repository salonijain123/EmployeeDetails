package com.example.demoApp.model;

 import javax.persistence.Entity;
import javax.persistence.Id;
 
 @Entity
 public class Employee {
	 
	 @Id
	 private int employee_id;
	 
	 private String name;
	 
	 private String email_id;
	 
	 private int salary;
	 
	 private int rating;
	 
	

	public int getEmployee_id() {
		return employee_id;
	}

	public String getName() {
		return name;
	}

	public String getEmail_id() {
		return email_id;
	}

	public int getSalary() {
		return salary;
	}

	public int getRating() {
		return rating;
	}

	

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	
	 
	 
 }