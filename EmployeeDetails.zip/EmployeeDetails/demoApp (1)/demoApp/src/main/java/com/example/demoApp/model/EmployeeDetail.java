package com.example.demoApp.model;

public class EmployeeDetail {
	
		 private int employee_id;
	 
	 private int updated_salary;
	 
	 private String email_id;
	 
	 private int salary;

	public int getEmployee_id() {
		return employee_id;
	}

	public int getUpdated_salary() {
		return updated_salary;
	}

	public String getEmail_id() {
		return email_id;
	}

	public int getSalary() {
		return salary;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public void setUpdated_salary(int updated_salary) {
		this.updated_salary = updated_salary;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	 

}
