package com.example.demoApp.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoApp.model.Employee;
import com.example.demoApp.model.EmployeeDetail;
import com.example.demoApp.repo.EmployeeRepository;

@Service
public class EmployeeService {
	
@Autowired
EmployeeRepository employeeRepository;

public Employee saveEmployee(Employee employee) {
	
	employeeRepository.save(employee);
	return employee;
	
	
	
}

public EmployeeDetail getEmployee(int id) {
	Optional<Employee> optional= employeeRepository.findById(id);
	
	Employee employee= optional.get();
	int rating= employee.getRating();
	int currentSalary= employee.getSalary();
	int updated_salary=findUpdatedSalary(rating,currentSalary);
	
	EmployeeDetail employeeDetail = new EmployeeDetail();
	employeeDetail.setEmail_id(employee.getEmail_id());
	employeeDetail.setSalary(employee.getSalary());
	employeeDetail.setUpdated_salary(updated_salary);
	employeeDetail.setEmployee_id(employee.getEmployee_id());
	
	return employeeDetail;
	
	
}

private int findUpdatedSalary(int rating, int currentSalary) {
	
	int new_salary =currentSalary + ( currentSalary * rating  / 100);
	
	return new_salary;
}
	
}
