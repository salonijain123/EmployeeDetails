package com.example.practicejava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

//spring context file
//controller registered as a bean and managed 
@SpringBootApplication
public class PracticeJavaApplication   {

		public static void main(String[] args) {
		SpringApplication.run(PracticeJavaApplication.class, args);
	}
		
		@Bean
		public RestTemplate restTemplate() {
		    return new RestTemplate();
		}
}

