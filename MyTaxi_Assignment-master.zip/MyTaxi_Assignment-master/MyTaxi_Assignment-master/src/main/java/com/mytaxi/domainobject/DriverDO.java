package com.mytaxi.domainobject;

import java.time.ZonedDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.OnlineStatus;

@Entity
@Table(
    name = "driver",
    uniqueConstraints = @UniqueConstraint(name = "uc_username", columnNames = {"usernameValue"})
)
public class DriverDO
{

    @Id
    @GeneratedValue
    private Long id;

    @Column(nullable = false)
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime dateCreated = ZonedDateTime.now();

    @Column(nullable = false)
    @NotNull(message = "Username can not be null!")
    private String usernameValue;

    @Column(nullable = false)
    @NotNull(message = "Password can not be null!")
    private String passwordValue;

    @Column(nullable = false)
    private Boolean deleted = false;

    @Embedded
    private GeoCoordinate coordinateValue;

    @Column
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime dateCoordinateUpdated = ZonedDateTime.now();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private OnlineStatus onlineStatusValue;
    
    //Added Car Mapping here
    @OneToOne
    @JoinColumn(name="car_id")
    private CarDO carDO;


    private DriverDO()
    {
    }

	public DriverDO(String usernameValue, String passwordValue)
    {
        this.usernameValue = usernameValue;
        this.passwordValue = passwordValue;
        this.deleted = false;
        this.coordinateValue = null;
        this.dateCoordinateUpdated = null;
        this.onlineStatusValue = OnlineStatus.OFFLINE;
    }


    public Long getId()
    {
        return id;
    }


    public void setId(Long id)
    {
        this.id = id;
    }


    public String getUsername()
    {
        return usernameValue;
    }


    public String getPassword()
    {
        return passwordValue;
    }


    public Boolean getDeleted()
    {
        return deleted;
    }


    public void setDeleted(Boolean deleted)
    {
        this.deleted = deleted;
    }


    public OnlineStatus getOnlineStatus()
    {
        return onlineStatusValue;
    }


    public void setOnlineStatus(OnlineStatus onlineStatusValue)
    {
        this.onlineStatusValue = onlineStatusValue;
    }


    public GeoCoordinate getCoordinate()
    {
        return coordinateValue;
    }


    public void setCoordinate(GeoCoordinate coordinateValue)
    {
        this.coordinateValue = coordinateValue;
        this.dateCoordinateUpdated = ZonedDateTime.now();
    }
    

    public CarDO getCarDO() {
		return carDO;
	}


	public void setCarDO(CarDO carDO) {
		this.carDO = carDO;
	}

}
