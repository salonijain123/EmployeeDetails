package com.mytaxi.datatransferobject;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mytaxi.domainvalue.GeoCoordinate;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DriverDTO implements Comparable<DriverDTO>
{
    @JsonIgnore
    private Long id;

    @NotNull(message = "Username can not be null!")
    private String usernameValue;

    @NotNull(message = "Password can not be null!")
    private String passwordValue;

    private GeoCoordinate coordinateValue;

    private DriverDTO()
    {
    }


    private DriverDTO(Long id, String usernameValue, String passwordValue, GeoCoordinate coordinateValue, CarDTO carDTO)
    {
        this.id = id;
        this.usernameValue = usernameValue;
        this.passwordValue = passwordValue;
        this.coordinateValue = coordinateValue;
    }


    public static DriverDTOBuilder newBuilder()
    {
        return new DriverDTOBuilder();
    }


    @JsonProperty
    public Long getId()
    {
        return id;
    }


    public String getUsername()
    {
        return usernameValue;
    }


    public String getPassword()
    {
        return passwordValue;
    }


    public GeoCoordinate getCoordinate()
    {
        return coordinateValue;
    }

    public static class DriverDTOBuilder
    {
        private Long id;
        private String usernameValue;
        private String passwordValue;
        private GeoCoordinate coordinateValue;
        private CarDTO carDTO;


        public DriverDTOBuilder setId(Long id)
        {
            this.id = id;
            return this;
        }


        public DriverDTOBuilder setUsername(String usernameValue)
        {
            this.usernameValue = usernameValue;
            return this;
        }


        public DriverDTOBuilder setPassword(String passwordValue)
        {
            this.passwordValue = passwordValue;
            return this;
        }


        public DriverDTOBuilder setCoordinate(GeoCoordinate coordinateValue)
        {
            this.coordinateValue = coordinateValue;
            return this;
        }


        public DriverDTOBuilder setCarDTO(CarDTO carDTO) {
			this.carDTO = carDTO;
			return this;
		}


		public DriverDTO createDriverDTO()
        {
            return new DriverDTO(id, usernameValue, passwordValue, coordinateValue, carDTO);
        }

    }

    @Override
    public int compareTo(DriverDTO o) {
		// TODO Auto-generated method stub
		if(this.id==o.id)
			return 0;
		else if(this.id<o.id)
			return -1;
		else
			return 1;
	}
}
