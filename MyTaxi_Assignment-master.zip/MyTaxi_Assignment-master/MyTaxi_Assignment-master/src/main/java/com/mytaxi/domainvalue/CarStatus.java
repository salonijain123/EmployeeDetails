package com.mytaxi.domainvalue;

public enum CarStatus
{
    MAP, UNMAP
}
