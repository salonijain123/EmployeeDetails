package com.example.demoApp.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoApp.model.Image;
import com.example.demoApp.repo.ImageRepo;
@Service
public class ImageService {
	
	@Autowired
	ImageRepo imageRepo;
	
	public Image saveImage(Image  image) {
		
	return	imageRepo.save(image);
		
		
	}
	
	public Image getImage(String name) {
		 Optional<Image> optional= imageRepo.findById(name);
		 return optional.get();
		
	}
	
	

}
