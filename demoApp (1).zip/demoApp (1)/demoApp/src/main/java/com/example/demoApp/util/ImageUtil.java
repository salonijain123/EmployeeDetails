package com.example.demoApp.util;
import java.util.Base64;

import org.springframework.stereotype.Service;


@Service
public class ImageUtil {
	
	
	   public String convertToEncodedImage(String a) {
	String originalInput = a;
	String encodedString = Base64.getEncoder().encodeToString(originalInput.getBytes());
	return encodedString;
	

}
}

