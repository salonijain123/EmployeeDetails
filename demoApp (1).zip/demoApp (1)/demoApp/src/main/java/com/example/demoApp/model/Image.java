package com.example.demoApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Image {

	@Id
	@Column(name = "Name",unique=true,columnDefinition="VARCHAR(64)")
    private String nameString;
	private String dataString;
	
	public String getNameString() {
		return nameString;
	}
	public String getDataString() {
		return dataString;
	}
	
	public void setNameString(String nameString) {
		this.nameString = nameString;
	}
	public void setDataString(String dataString) {
		this.dataString = dataString;
	}
	
	

}
