package com.example.demoApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoApp.model.Image;
import com.example.demoApp.services.ImageService;
import com.example.demoApp.util.ImageUtil;

@RestController
public class ImageController {

	@Autowired
	ImageUtil imgUtilObject;
	
	@Autowired
	ImageService imageService;
	
	
	
	@PostMapping("/postImage")
	public  Image postImage(@RequestBody Image image) {
		
		String dataString = imgUtilObject.convertToEncodedImage(image.getDataString());
		
		image.setDataString(dataString);
		
		return imageService.saveImage(image);
         
      		
		
	}
	
	@GetMapping("/getImage")
	public  Image getImage(@RequestParam String name) {
		
		return imageService.getImage(name);         
      		
		
	}

	
	

}
